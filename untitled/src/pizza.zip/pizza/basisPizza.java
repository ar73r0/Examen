package pizza;

public interface basisPizza {
    public String name();
    public double price();
    public String Topping1();
    public String Topping2();


}
